import update_db
update_db.device_init()

import container_control
import wamp_server
import request_handler