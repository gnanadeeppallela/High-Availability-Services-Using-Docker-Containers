"""
Edge Computing Embedded Platform
Developed by Abhishek Gurudutt, Chinmayi Divakara
Praveen Prabhakaran, Tejeshwar Chandra Kamaal

"""

import ecep_db as ecep_db
import ecep_wampServer as ecep_wampServer