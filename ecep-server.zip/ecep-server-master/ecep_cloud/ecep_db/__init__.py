"""
Edge Computing Embedded Platform
Developed by Abhishek Gurudutt, Chinmayi Divakara,
Praveen Prabhakaran, Tejeshwar Chandra Kamaal
"""

from controller import *

controller.set_db_session()
controller.init_db_lock()